import pandas as pd
import glob
from datetime import datetime, timedelta
import unicodedata

# -------------------------------------- useful functions ---------------------------------------- ##


def split_str(string, idx=0):
    try:
        return string.split(sep=" ")[idx]
    except AttributeError:
        return string


def create_id(dt):
    dt = str(dt)
    res = ""
    for i in list(reversed(dt.split(sep="-"))):
        res += i + "_"
    return res


def time(t):
    try:
        return datetime.strptime(t, "%H:%M").time()
    except TypeError:
        # print(t)
        return None


def clean(val: str):
    for ch in ["₪", ","]:
        val = val.replace(ch, "")

    return eval(val)


def date(d): return datetime.strptime(d, "%d/%m/%Y").date()


# ---------------------------------- cleaning the tables data-------------------------------------------##


def clean_tables_data():
    tables_raw = glob.glob("./data/tables/*")

    sub_dfs = []
    missing = []

    for file in tables_raw:
        df = pd.read_csv(file, header=None)
        df.drop(columns=[0], inplace=True)
        df.drop(index=[2, 3], inplace=True)

        sahac = df.dropna(subset=[1])
        sahac_idx = sahac[sahac[1].str.contains('סה"כ')].index
        df.drop(index=sahac_idx, inplace=True)

        df[1] = df[1].fillna(method="ffill").apply(lambda string: split_str(string))

        sahac = df.dropna(subset=[2])
        sahac_idx = sahac[sahac[2].str.contains('סה"כ')].index
        df.drop(index=sahac_idx, inplace=True)

        df[2] = df[2].apply(lambda string: split_str(string, 1))

        cols = list(df.columns)
        col_groups = []
        j = 0
        for i in range(len(cols)):
            if (i + 1 - j) % 3 == 0:
                col_groups.append(cols[j:i + 1])
                j = i + 1

        for i in range(1, len(col_groups)):
            sub_df = df[col_groups[0] + col_groups[i]].copy().reset_index().drop(columns="index")
            waiter = list(sub_df.loc[0])[3]
            if waiter == 'סה"כ':
                waiter = "missing"
            # print(file.split(sep='./data/tables/')[1], waiter)
            header = ["date", "order_id", "start"] + list(sub_df.loc[1])[3:]
            sub_df.drop(index=[0, 1], inplace=True)
            sub_df.columns = header

            sub_df.start = sub_df.start.apply(lambda t: time(t))
            sub_df["DATE"] = sub_df.date.apply(lambda d: date(d))

            lastDay = sub_df[sub_df.start < time('05:00')].index
            for i in lastDay:
                sub_df.loc[i, 'DATE'] = sub_df.loc[i, 'DATE'] - timedelta(days=1)
            sub_df.order_id = sub_df.DATE.apply(lambda dt: create_id(dt)) + sub_df.order_id.apply(lambda id: str(id))
            sub_df.drop(columns="DATE", inplace=True)

            # sub_df.order_id = sub_df.date.apply(lambda date: date.replace("/", "_") + "_") + sub_df.order_id

            if "הזמנות" in header:
                sub_df.rename(columns={"הזמנות": "Reserved", "סועדים": "num_customers", "זמן ישיבה": "sitting_time"},
                              inplace=True)
            elif "לקוחות" in header:
                sub_df.rename(columns={"לקוחות": "Reserved", "סועדים": "num_customers", "זמן ישיבה": "sitting_time"},
                              inplace=True)

            sub_df["waiter"] = waiter
            if waiter == "missing":
                missing.append(sub_df)
            else:
                sub_df.dropna(inplace=True)
                sub_dfs.append(sub_df)

    tables = pd.concat(sub_dfs, ignore_index=True)
    tables.date = tables.date.apply(lambda d: date(d))

    waiter_dict = {}
    waiters = pd.read_csv("./data/waiters.csv")
    for i in range(len(waiters)):
        waiter_dict[waiters.loc[i, "heb"]] = waiters.loc[i, "eng"]
    waiter_dict["missing"] = "missing"
    missing = pd.concat(missing, ignore_index=True)
    missing.date = missing.date.apply(lambda d: date(d))
    has_waiter = list(tables["order_id"])
    missing.drop(index=missing[missing.order_id.isin(has_waiter)].index, inplace=True)
    tables = pd.concat([tables, missing.dropna()], ignore_index=True).sort_values(["date", "order_id"])
    tables["day"] = tables.date.apply(lambda d: d.weekday() + 2 if d.weekday() < 6 else 1)
    tables.waiter = tables.waiter.apply(lambda waiter: waiter_dict[waiter])
    remove_idx = list(tables[(tables.day < 6) & (tables.start < time("17:00")) & (tables.start > time("03:00"))].index)
    tables.drop(index=remove_idx, inplace=True)
    tables.drop(columns="Reserved", inplace=True)
    return tables


# ---------------------------------- cleaning the sales data-------------------------------------------##
def clean_sales_data():
    raw_sales = glob.glob("./data/sales/*")
    dictionary = pd.read_csv('./data/Dictionary_updated_V3.csv')
    env = pd.read_csv('./data/environment.csv')
    env.date = env.date.apply(lambda d: datetime.strptime(d, '%d/%m/%Y').date())
    env.rename(columns={"name": "holiday_det"}, inplace=True)

    Dictionary = dict()
    for i in range(0, len(dictionary)):
        Dictionary[dictionary.loc[i].heb] = dictionary.loc[i].eng

    def translate(name, lst: list):
        if 'HEBREW' in unicodedata.name(name.strip()[0]) or 'HEBREW' in unicodedata.name(name.strip()[-1]):
            try:
                return Dictionary[name].strip()
            except KeyError:
                lst.append(name)
                return name
        else:
            try:
                return Dictionary[name].strip()
            except KeyError:
                # print(name.title())
                return name.title()

    cols = ["remove0", "date", "order_id", "name", "time", "remove1", "num_items", "remove2"]
    mapper = list(map(lambda filename: pd.read_csv(filename, index_col=None, names=cols), raw_sales))
    sales = pd.concat(mapper, axis=0, ignore_index=True)

    sales.drop(["remove0", "remove1", "remove2"], axis=1, inplace=True)
    sales.date.fillna(method='ffill', inplace=True)
    sales.order_id.fillna(method='ffill', inplace=True)
    sales.dropna(subset=["time"], inplace=True)
    sales.dropna(subset=["name"], inplace=True)

    remove_idx = list()
    remove_keywords = ['מבוגר', 'מדריך', 'אירוע', 'תחילת ארוחה', 'הערה', 'כוסות', 'פתיח רגיל סילבסטר', 'המתנה לעיקרית',
                       'מטבח סגור', 'טעימות זוגי', 'טעימה לבן', 'ילד 80','רוז בתשלום', 'פריט כללי', 'טעימת יין אדום',
                       "צ'ייסר ב10", 'טעימות תבור', 'טעימת יין לבן', 'כוס טעימה אדום', 'תוספת יין',
                       'ISTUDENT זוגי', '2 ב 70',
                       "פתיחים", "פתיח טבעוני", "בייקון טלה", "שתייה חמה", "מקאלן מהדורה 3", "טיפ", '0']

    for keyword in remove_keywords:
        remove_idx += list(sales[sales.name.str.contains(keyword)].index)
    sales.drop(index=remove_idx, inplace=True)

    missing_values = list()
    sales.name = sales.name.apply(lambda name: translate(name, missing_values))
    sales.order_id = sales.order_id.apply(lambda _id: _id.split(sep=" ")[1])
    sales["date"] = sales.date.apply(lambda date: datetime.strptime(date.split(sep=" ")[0], "%d/%m/%Y").date())
    sales.time = sales.time.apply(lambda dt: datetime.strptime(dt, "%H:%M").time())

    missing_dates = []
    for d in list(env.date):
        if d not in list(set(sales.date)):
            missing_dates.append(d)

    add = env[env.date.isin(missing_dates)].copy()
    add["time"] = time("17:00")
    add["num_items"] = 1
    add["order_id"] = 999
    add.rename(columns={"holiday_det": "name"}, inplace=True)

    relevant = ["date", "time", "order_id", "name", "num_items"]

    sales = sales[relevant]
    add = add[relevant]

    sales = pd.concat([sales, add], ignore_index=True)
    sales = sales.sort_values(by="date", ignore_index=True)

    sales["day"] = sales.date.apply(lambda dt: dt.weekday())
    sales["day"] = sales["day"].apply(lambda d: d+2 if d<6 else 1)
    sales = sales[["date", "day", "time", "order_id", "name", "num_items"]]

    clean1 = list(sales[(sales.day >= 6) & (sales.time < time("11:00")) & (sales.time > time("03:00"))].index)
    clean2 = list(sales[(sales.day < 6) & (sales.time < time("17:00")) & (sales.time > time("03:00"))].index)
    clean = clean1 + clean2
    sales.drop(index=clean, inplace=True)

    sales["DATE"] = sales.date
    lastDay = sales[sales.time < time("05:00")].index
    for i in lastDay:
        sales.loc[i, 'DATE'] = sales.loc[i, 'DATE'] - timedelta(days=1)

    sales.order_id = sales.DATE.apply(lambda dt: create_id(dt)) + sales.order_id.apply(
        lambda id: str(id))

    sales.drop(columns="DATE", inplace=True)
    return sales


tables = clean_tables_data()
sales = clean_sales_data()


table_order_ids = list(tables.order_id.unique())
sales_order_ids = list(sales.order_id.unique())

events_sales = []

for sale_id in sales_order_ids:
    if sale_id in table_order_ids:
        continue
    else:
        events_sales.append(sale_id)

sales.drop(index=list(sales[sales.order_id.isin(events_sales)].index), inplace=True)

tables.to_csv("./proc_data/tables.csv", index=False)
sales.to_csv("./proc_data/sales.csv", index=False)



